import java.util.List;
import java.util.Map;

public class Recursion {

	/**
	 * Returns the nth term in the Fibonacci sequence.
	 * 
	 * @param n the term index
	 * @return the nth Fibonacci number
	 * @throws IllegalArgumentException if n is less than 0
	 */
	public static int fibonacci(int n) {
		return 0;
	}
	
	/**
	 * Returns the nth term in the Fibonacci sequence using a map to memoize 
	 * the method. If the term is stored in the map, its value is returned. 
	 * Otherwise, the term is calculated and added to the map before returning 
	 * it.
	 * 
	 * @param n the term index
	 * @param cache the map used to memoize the method
	 * @return the nth Fibonacci number
	 * @throws IllegalArgumentException if n is less than 0
	 */
	public static int fibonacci(int n, Map<Integer, Integer> cache) {
		return 0;
	}
	
	/**
	 * Searches a sorted list of strings using binary search. Returns a list of 
	 * the indices of the strings checked during the search in the order they 
	 * are checked. If the target string is not found, the last element of the 
	 * returned list is -1. Otherwise, the last element is the index of the 
	 * target.
	 * 
	 * @param words the list to be searched
	 * @param target the string to be searched for
	 * @param fromIdx the index of the first string in the range of strings to 
	 *        be searched (inclusive)
	 * @param toIdx the index of the last string in the range of strings to be 
	 *        searched (inclusive)
	 * @return a list of the indices of the strings checked during the search.
	 *         The last element is -1 if the target is not found.
	 */
	public static List<Integer> binarySearch(List<String> words, String target, 
			int fromIdx, int toIdx) {
		return null;
	}
	
	/**
	 * Returns a list of moves that solve the Tower of Hanoi puzzle. The method 
	 * assumes that the disks are initially on the given start peg and that the 
	 * puzzle is solved by moving them to the given end peg.
	 * 
	 * @param numDisks the number of disks in the puzzle
	 * @param start the start peg
	 * @param end the end peg
	 * @return a list of legal moves that transfers the disks from the start 
	 *         peg to the end peg
	 * @throws IllegalArgumentException if numDisks is less than or equal to 0
	 */
	public static List<Move> solveTower(int numDisks, Peg start, Peg end) {
		return null;
	}
	
	/**
	 * Returns a sorted list of all the unique sums that can be calculated from 
	 * subsets of the integers in a given list.
	 * 
	 * @param numbers the list of integers
	 * @return the sorted list of unique sums
	 */
	public static List<Integer> subsetSums(List<Integer> numbers) {
		return null;
	}
}
