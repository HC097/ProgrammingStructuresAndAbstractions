/**
 * IllegalMoveException is thrown by the TowerOfHanoi moveDisk method.
 */
public class IllegalMoveException extends Exception {

	private static final long serialVersionUID = 1L;
}
